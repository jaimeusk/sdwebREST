package com.dam.clientesdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void clicBtn_Cliente (View view) {
        Intent intent = new Intent(this, ClienteSDSW.class);
        startActivity(intent);
    }

    public void clicBtn_Administrador (View view) {
        Intent intent = new Intent(this, AdministradorSDSW.class);
        startActivity(intent);
    }
}