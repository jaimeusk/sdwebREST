package com.dam.clientesdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class ClienteSDSW extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_sdsw);
    }

    public void clicBtn_ComprarEntradas (View view) {
        Intent intent = new Intent(this, ComprarEntrada.class);
        startActivity(intent);
    }

    public void clicBtn_CancelarEntradas (View view) {
        //Intent intent = new Intent(this, CancelarEntrada.class);
        //startActivity(intent);
    }

    public void clicBtn_EntradasCompradas (View view) {
        //Intent intent = new Intent(this, EntradasCompradas.class);
        //startActivity(intent);
    }

    public void clicBtn_CambiarAsientos (View view) {
        //Intent intent = new Intent(this, CambiarAsientos.class);
        //startActivity(intent);
    }
}