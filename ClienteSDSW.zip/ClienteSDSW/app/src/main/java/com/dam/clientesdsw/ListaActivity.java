package com.dam.clientesdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class ListaActivity extends Activity {

    private ListView lista;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        //Todos estos eventos se obtendrían de la base de datos
        Evento evento1 = new Evento (1, "Quevedo", "Sevilla", "Maestranza", "23/07/23", 400, 2);
        Evento evento2 = new Evento (2, "Shakira", "Madrid", "WeZink Center", "08/08/23", 1200, 3);
        Evento evento3 = new Evento (3, "Myke Towwers", "A Coruña", "Coliseum", "07/07/23", 560, 1);
        Evento evento4 = new Evento (4, "Romeo Sandos", "Marbella", "Oasisss Marbella", "15/07/23", 780, 2);
        Evento evento5 = new Evento (5, "Tini", "Chiclana de la Frontera", "Concert Music Festival", "01/07/23", 995, 3);
        Evento evento6 = new Evento (6, "Hombres G", "Valencia", "La Marina", "19/09/23", 430, 2);
        Evento evento7 = new Evento (7, "Bad Bunny", "Gijón", "Palacio Deportes Adolfo Suárez", "03/08/23", 678, 1);
        Evento evento8 = new Evento (8, "CTangana", "Badajoz", "Auditurio Badajoz-Recinto Ferial", "23/06/23", 763, 3);

        ArrayList<Evento> datos = new ArrayList();
        datos.add(evento1);
        datos.add(evento2);
        datos.add(evento3);
        datos.add(evento4);
        datos.add(evento5);
        datos.add(evento6);
        datos.add(evento7);
        datos.add(evento8);

        lista = (ListView) findViewById(R.id.ListView_listado);
        lista.setAdapter(new Lista_adaptador(this, R.layout.evento, datos){

            @Override
            public void onEntrada(Object entrada, View view) {
                if (entrada != null) {
                    TextView texto_artista = (TextView) view.findViewById(R.id.Relleno_Artista);
                    if (texto_artista != null)
                        texto_artista.setText(((Evento) entrada).getNombreArtista());

                    TextView texto_ciudad = (TextView) view.findViewById(R.id.Relleno_Ciudad);
                    if (texto_ciudad != null)
                        texto_ciudad.setText(((Evento) entrada).getCiudad());

                    TextView texto_recinto = (TextView) view.findViewById(R.id.Relleno_Recinto);
                    if (texto_recinto != null)
                        texto_recinto.setText(((Evento) entrada).getRecinto());

                    TextView texto_fecha = (TextView) view.findViewById(R.id.Relleno_Fecha);
                    if (texto_fecha != null)
                        texto_fecha.setText(((Evento) entrada).getFecha());

                    TextView texto_numEntradas = (TextView) view.findViewById(R.id.Relleno_NumEntradas);
                    if (texto_numEntradas != null)
                        texto_numEntradas.setText(Integer.toString(((Evento) entrada).getNumEntradas()));

                }
            }
        });
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                TextView textoArtista = (TextView) view.findViewById(R.id.Relleno_Artista);
                TextView textoCiudad = (TextView) view.findViewById(R.id.Relleno_Ciudad);
                TextView textoRecinto = (TextView) view.findViewById(R.id.Relleno_Recinto);
                TextView textoFecha = (TextView) view.findViewById(R.id.Relleno_Fecha);
                TextView textoNumEntradas = (TextView) view.findViewById(R.id.Relleno_NumEntradas);
                CharSequence texto = "Seleccionado el evento del artista: " + textoArtista.getText();
                Toast.makeText(getApplicationContext(), texto, Toast.LENGTH_SHORT).show();
                Intent retorno = new Intent();
                retorno.putExtra("artista",textoArtista.getText());
                retorno.putExtra("ciudad", textoCiudad.getText());
                retorno.putExtra("recinto", textoRecinto.getText());
                retorno.putExtra("fecha", textoFecha.getText());
                retorno.putExtra("numEntradas", textoNumEntradas.getText());
                setResult(RESULT_OK, retorno);
                finish();

            }
        });
    }
}