package com.dam.clientesdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.Date;

public class Evento {

    private int id;
    private String nombreArtista;
    private String ciudad;
    private String recinto;
    private String fecha;
    private int numEntradas;
    private int tipoEscenario;

    public Evento (int id, String nombreArtista, String ciudad, String recinto, String fecha, int numEntradas, int tipoEscenario) {
        this.id = id;
        this.nombreArtista = nombreArtista;
        this.ciudad = ciudad;
        this.recinto = recinto;
        this.fecha = fecha;
        this.numEntradas = numEntradas;
        this.tipoEscenario = tipoEscenario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreArtista() {
        return nombreArtista;
    }

    public void setNombreArtista() {
        this.nombreArtista = nombreArtista;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getRecinto() {
        return recinto;
    }

    public void setRecinto(String recinto) {
        this.recinto = recinto;
    }

    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getNumEntradas() {
        return numEntradas;
    }

    public void setNumEntradas(int numEntradas) {
        this.numEntradas = numEntradas;
    }

    public int getTipoEscenario() {
        return tipoEscenario;
    }

    public void setTipoEscenario(int tipoEscenario) {
        this.tipoEscenario = tipoEscenario;
    }



}