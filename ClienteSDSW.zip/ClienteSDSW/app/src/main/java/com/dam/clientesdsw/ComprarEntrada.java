package com.dam.clientesdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.Toast;

public class ComprarEntrada extends Activity {

    private final static int LISTA = 1;

    CheckedTextView artista;
    CheckedTextView ciudad;
    CheckedTextView recinto;
    CheckedTextView fecha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comprar_entrada);

        artista = (CheckedTextView) findViewById(R.id.checked_Artista);
        ciudad = (CheckedTextView) findViewById(R.id.checked_Ciudad);
        recinto = (CheckedTextView) findViewById(R.id.checked_Recinto);
        fecha = (CheckedTextView) findViewById(R.id.checked_Fecha);
    }
    public void clicBtn_ListarEventos (View view) {
        Intent intent = new Intent(this, ListaActivity.class);
        startActivityForResult(intent,LISTA);
    }

    public void clicBtn_Comprar (View view) {
        EditText nombre = (EditText) findViewById(R.id.editText_Nombre7);
        EditText apellidos = (EditText) findViewById(R.id.editText_Apellidos);
        EditText DNI = (EditText) findViewById(R.id.editText_DNI);
        if (nombre.getText().toString().equals("Nombre") || apellidos.getText().toString().equals("Apellidos") || DNI.getText().toString().equals("DNI")) {
            AlertDialog.Builder alerta = new AlertDialog.Builder(this);
            alerta.setMessage("Hay campos que no se han rellenado");
            alerta.setTitle("Error, faltan datos...");
            alerta.setIcon(android.R.drawable.ic_dialog_alert);
            alerta.setCancelable(false);
            alerta.setPositiveButton("Volver", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {}
            });
            alerta.show();
        } else {
            Intent intent = new Intent(this, ClienteSDSW.class);
            Toast.makeText(getApplicationContext(), "Entrada comprada con éxito", Toast.LENGTH_LONG).show();
            startActivity(intent);
            //Aquí habría que enviar al servidor la peticion para la compra de la entrada especificada
        }
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("En onActivityResult");
        if (requestCode == LISTA) {
            if (resultCode == RESULT_OK) {
                String nombre_artista = data.getStringExtra("artista");
                String nombre_ciudad = data.getStringExtra("ciudad");
                String nombre_recinto = data.getStringExtra("recinto");
                String nombre_fecha = data.getStringExtra("fecha");

                artista.setText(nombre_artista);
                ciudad.setText(nombre_ciudad);
                recinto.setText(nombre_recinto);
                fecha.setText(nombre_fecha);
            }
        }
    }
}